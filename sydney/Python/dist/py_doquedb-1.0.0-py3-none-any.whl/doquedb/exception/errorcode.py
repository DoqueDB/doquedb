"""errorcode.py -- 自動生成されたエラーコードクラス
"""
from enum import IntEnum, unique


@unique
class ErrorCode(IntEnum):
    """DoqueDBのエラーコードクラス"""
    # ?を用いたSQL文に対して必要な数のパラメーターが指定されていない
    DynamicParameterNotMatch = 0x10000401

    # 存在しないセッションIDが渡された
    ConnectionNotExist = 0x10000503

    # 存在しないクライアントIDが渡された
    ClientNotExist = 0x10000508

    # 存在しないセッションIDが渡された
    SessionNotExist = 0x10000509

    # 正しくないパスワードが指定された
    AuthorizationFailed = 0x10000551

    # 実装されていない機能を使用しようとした
    NotSupported = 0x00000005

    # 全文索引が定義されていないのに全文索引が必要な機能を使用しようとした
    FullTextIndexNeeded = 0x10000751

    # 空間索引が定義されていないのに空間索引が必要な機能を使用しようとした
    SpatialIndexNeeded = 0x10000752

    # 指定されたロールが登録されていない
    RoleNotFound = 0x10000e51

    # row subqueryにあたる場所で結果が2行以上だった
    CardinalityViolation = 0x10001601

    # 制限長のある文字列型へのキャストで制限長を超える部分があった。
    StringRightTruncation = 0x10001702

    # 四則演算などの結果数値型で表現できる範囲を超える操作があった。
    NumericValueOutOfRange = 0x10001704

    # ナル値が許されない操作をした。
    NullNotAllowed = 0x10001705

    # 日時型へのキャストで日時型に変換できない文字列が渡された。
    InvalidDatetimeFormat = 0x10001708

    # シーケンスの値が最大値になった。
    SequenceLimitExceeded = 0x10001711

    # SUBSTRINGでstart positionが長さを超えていた。
    SubStringError = 0x10001715

    # 割り算のdivisorが0だった。
    DivisionByZero = 0x10001716

    # 文字列型をキャストするときにターゲットの型に対して不正な文字が含まれていた。
    InvalidCharacter = 0x10001719

    # LikeやSimilarに指定したエスケープ文字の長さが1でなかった。
    InvalidEscape = 0x1000171a

    # Similarに指定した正規表現が正しくない。
    InvalidRegularExpression = 0x1000171b

    # char型の列にASCII以外の文字を渡した。
    CharacterNotInRepertoire = 0x10001720

    # 以下の条件を満たさなかった: likeのパターンが1文字か2文字の部分に分解できて、1文字の部分はエスケープ文字以外からなり、2文字の部分はエスケープ文字とエスケープ文字かアンダースコアかパーセント記号の連結である。
    InvalidEscapeSequence = 0x10001724

    # 文字列中にUCSではないデータが含まれている。
    NonCharacterInString = 0x10001726

    # ARRAYの要素指定が範囲外だった。
    BadArrayElement = 0x10001728

    # ARRAYの代入で代入もとの要素数が代入先の最大長を超えていた。
    ArrayRightTruncation = 0x10001729

    # オブジェクトの内容を別のクラスにキャストしようとして失敗した
    ClassCast = 0x00010002

    # 全文索引に使うセクションデータと言語データの次数があっていない
    InvalidSectionData = 0x10001752

    # INSERT INPUT FROM構文などで指定したデータファイルが規定のフォーマットに合わない
    InvalidDataFile = 0x10001760

    # それを実行するとインテグリティを破ってしまうようなデータ操作を行おうとした
    IntegrityViolation = 0x00070001

    # 挿入または更新でNOT NULLの制約がついている列にNULLの値を設定しようとした
    NullabilityViolation = 0x10001851

    # UNIQUE制約に違反するデータ操作を行おうとした
    UniquenessViolation = 0x10001852

    # 外部キーで参照しているレコードに存在しない値を設定しようとした
    ForeignKeyViolation = 0x10001853

    # 外部キーで参照されている列を削除または更新しようとした
    ReferedKeyViolation = 0x10001854

    # トランザクション中にトランザクションを開始しようとした。または、トランザクションブランチを開始もしくは待機しようとした
    AlreadyBeginTransaction = 0x00090001

    # データ操作中のトランザクションブランチにおいて不可なトランザクション操作・トランザクションブランチ操作を行おうとした
    XA_InsideActiveBranch = 0x00001a03

    # 読み取り専用トランザクションで許されない操作を行おうとした
    ReadOnlyTransaction = 0x00090003

    # 明示的に開始されたトランザクション中にスキーマ操作を行おうとした
    InvalidExplicitTransaction = 0x10001a51

    # トランザクション中に行うべき処理をトランザクションを開始せずに行おうとした
    NotBeginTransaction = 0x10001a52

    # トランザクションの読み書き属性かアイソレーションレベルが行おうとした操作で許されていないものだった。
    BadTransaction = 0x00090004

    # 『データ操作中』・『中断中』・『待機中』のトランザクションブランチのトランザクションブランチ識別子を指定して新たにトランザクションブランチを開始した。
    XA_DuplicateIdentifier = 0x00001a54

    # ある状態のトランザクションブランチに対して許されない操作を行おうとした。
    XA_ProtocolError = 0x00001a55

    # 存在しないトランザクションブランチ識別子が指定された。
    XA_UnknownIdentifier = 0x00001a56

    # トランザクションブランチはコミットしてヒューリスティックに解決済である。
    XA_HeurCommit = 0x00001a57

    # トランザクションブランチはロールバックしてヒューリスティックに解決済である。
    XA_HeurRollback = 0x00001a58

    # トランザクションブランチは部分的にコミットされ、そして部分的にロールバックしてヒューリスティックに解決済である。
    XA_HeurMix = 0x00001a59

    # 不正なトランザクションブランチ識別子が指定された。
    XA_InvalidIdentifier = 0x00001a5A

    # 1つのトランザクションまたはトランザクションブランチで2つのデータベースを更新しようとした。
    OtherDatabaseAlreadyModified = 0x00001a5B

    # 指定されたユーザーが登録されていない
    UserNotFound = 0x10001d51

    # ユーザー名が指定されていない
    UserRequired = 0x10001d52

    # すでに登録済みのユーザー名でユーザーを作成しようとした
    DuplicateUser = 0x10001d53

    # ユーザー名の長さが制限長を超えている
    TooLongUserName = 0x10001d54

    # ユーザー名にサポート外の文字が使用されている。
    InvalidUserName = 0x10001d55

    # すでに登録済みのユーザーIDを指定してユーザーを作成しようとした
    DuplicateUserID = 0x10001d56

    # ユーザーIDに使用できない数値が指定されている。または自動割当のユーザーIDが範囲を超えた。
    UserIDOutOfRange = 0x10001d57

    # 指定された識別子に対応するSQLステートメントがない
    InvalidStatementIdentifier = 0x10002401

    # 与えられた名前のエリアは存在しない
    AreaNotFound = 0x00040001

    # 与えられた名前のデータベースは存在しない
    DatabaseNotFound = 0x00040002

    # 与えられた名前の表は存在しない
    TableNotFound = 0x00040003

    # 与えられた名前の列は存在しない
    ColumnNotFound = 0x00040004

    # 与えられた名前の制約は存在しない
    ConstraintNotFound = 0x00040005

    # 与えられた名前の索引は存在しない
    IndexNotFound = 0x00040006

    # 与えられた名前のキーは存在しない
    KeyNotFound = 0x00040007

    # IDなどによるスキーマ情報の取得に失敗した
    SchemaObjectNotFound = 0x000400ff

    # 与えられた名前の関数は存在しない
    StoredFunctionNotFound = 0x10002e59

    # 与えられた名前の子サーバーは存在しない
    CascadeNotFound = 0x10002e5a

    # 与えられた名前の表にルールは存在しない
    PartitionNotFound = 0x10002e5b

    # 与えられた名前のエリアがある
    AreaAlreadyDefined = 0x10002e61

    # 与えられた名前のデータベースがある
    DatabaseAlreadyDefined = 0x10002e62

    # 与えられた名前の表がある
    TableAlreadyDefined = 0x10002e63

    # 与えられた名前の列がある
    ColumnAlreadyDefined = 0x10002e64

    # 与えられた名前の制約がある
    ConstraintAlreadyDefined = 0x10002e65

    # 与えられた名前の索引がある
    IndexAlreadyDefined = 0x10002e66

    # 与えられた名前のキーがある
    KeyAlreadyDefined = 0x10002e67

    # 与えられた名前の子サーバーがある
    CascadeAlreadyDefined = 0x10002e68

    # 与えられた名前の関数がある
    StoredFunctionAlreadyDefined = 0x10002e69

    # 与えられた名前の表にルール定義がある
    PartitionAlreadyDefined = 0x10002e6a

    # 子サーバーの指定が正しくない
    InvalidCascade = 0x10002e6b

    # ルールの指定が正しくない
    InvalidPartition = 0x10002e6c

    # 表が空でないとできない操作をした
    TableNotEmpty = 0x10002e6d

    # 使用中の関数をDROPしようとした
    StoredFunctionUsed = 0x10002e6e

    # 参照専用ルールの定義されている表に更新操作を行おうとした
    ReadOnlyPartition = 0x10002e6f

    # 構文が正しくないSQL文が与えられた
    SQLSyntaxError = 0x00030001

    # 列に渡された長さが制限値を超えていた
    ColumnLengthOutOfRange = 0x10003051

    # スキーマオブジェクト名の長さが制限値を超えていた
    TooLongObjectName = 0x10003052

    # 外部キーで参照している列がUniqueではないなど正しく設定されていない
    InvalidReference = 0x10003053

    # create databaseで指定されたパスがすでにあったり、mountで指定されたパスが存在しないなど
    InvalidPath = 0x10003054

    # 一時表に対して許されていない操作を行おうとした
    TemporaryTable = 0x10003055

    # add columnでNOT NULL制約のついている列にはDEFAULT指定が必要である
    DefaultNeeded = 0x10003056

    # 列の型に代入可能でない型がDEFAULT指定で用いられている
    InvalidDefault = 0x10003057

    # IDENTITY列は1つの表に1つしか定義できない
    DuplicateIdentity = 0x10003058

    # 索引のキーとしてサポートしていない型の列を指定した
    InvalidIndexKey = 0x10003059

    # 列に渡された精度が制限値を超えていた
    ColumnPrecisionOutOfRange = 0x1000305a

    # 列に渡された桁が制限値を超えていた
    ColumnScaleOutOfRange = 0x1000305b

    # 識別子に使えない文字が含まれている
    InvalidIdentifier = 0x1000305c

    # レプリケーションが開始されているデータベースにエリア指定のあるスキーマ操作をした
    InvalidAreaSpecification = 0x1000305d

    # そのオブジェクトに依存している別のオブジェクトがあるのにdropなどの操作をしようとした
    OtherObjectDepending = 0x100030a1

    # 必要な権限が与えられていない操作をしようとした
    PrivilegeNotAllowed = 0x100030b1

    # 導出列の数が表の列数と異なっていた
    InvalidDerivedColumn = 0x100030c1

    # ROW型の値に別名をつけようとした
    InvalidDerivedName = 0x100030c2

    # 同じスコープ中に表や列の別名を重複して使用している
    DuplicateQualifiedName = 0x100030c3

    # ROW型値の比較などで異なる次数のものを指定している
    InvalidRowValue = 0x100030c4

    # 比較可能でない型同士を比較しようとした
    NotComparable = 0x100030c5

    # 副問合せの使用位置が不正だった
    InvalidSubQuery = 0x100030c6

    # 列の位置を指定するのに次数を超えた値を指定した
    ExceedDegree = 0x100030c7

    # EXPAND句に1または2でない次数の副問い合わせを指定した
    InvalidExpandDegree = 0x100030c8

    # EXPAND句に不正なORDER BYを指定した
    InvalidExpandOrder = 0x100030c9

    # EXPAND句に不正なLIMITを指定した
    InvalidExpandLimit = 0x100030ca

    # SELECT句にWORDとSCOREなど同時に使用できないものを使用した
    InvalidFullTextUsage = 0x100030cb

    # 集約関数をSELECT句、HAVING句、ORDER BY句以外に使用した
    InvalidSetFunction = 0x100030cc

    # GROUP BYで指定されていない列がグルーピングされたリレーションの中で単独で使用されている
    NonGroupingColumn = 0x100030cd

    # 配列でないものに要素参照したか要素指定が数値でない
    InvalidElementReference = 0x100030ce

    # 配列の任意要素指定を使用できない箇所で使用している
    ArbitraryElementNotAllowed = 0x100030cf

    # COLUMN指定のJOINで指定した名前の共通列がなかった
    CommonColumnNotFound = 0x100030d0

    # COLUMN指定のJOINで指定した名前の列が複数あった
    DuplicateCommonColumn = 0x100030d1

    # KwicがSELECT句以外に現れているか、引数が文字列でない
    InvalidKwic = 0x100030d2

    # KwicがCONTAINSなしに使用されている
    KwicWithoutContains = 0x100030d3

    # EXPAND句に外部参照がある
    OuterReferenceNotAllowed = 0x100030d4

    # 配列でないものにCARDINALITYを適用しようとした
    InvalidCardinality = 0x100030d5

    # 文字列でないものにLIKEを適用しようとした
    InvalidLike = 0x100030d6

    # 文字列でないものにSIMILARを適用しようとした
    InvalidSimilar = 0x100030d7

    # キャスト可能でない型同士に関数または演算子を適用しようとした
    NotCompatible = 0x100030d8

    # 関数の使用方法が正しくない
    InvalidFunction = 0x100030d9

    # 定義されていない変数名を使用した
    VariableNotFound = 0x100030da

    # 定義されている変数名と同じ名前を使用した
    DuplicateVariable = 0x100030db

    # RANK FROM句に異なる表を含む副問い合わせが使用されている
    InvalidRankFrom = 0x100030de

    # IS SUBSTRING OFの引数に配列でない値が指定されている
    InvalidSubstringOf = 0x100030df

    # ROWIDなど更新操作で指定できない列が指定されている。
    InvalidUpdateColumn = 0x100030e0

    # 挿入や更新で同じ列が2回以上あらわれている
    DuplicateUpdateColumn = 0x100030e1

    # INSERT文の入力と列の数が一致しない
    InvalidInsertSource = 0x100030e2

    # バルクオプションに誤りがある。
    InvalidBulkParameter = 0x100030f0

    # 想定していないエラーが発生した
    Unexpected = 0x00000001

    # 新たにメモリーを確保しようとしたが失敗した
    MemoryExhaust = 0x00000002

    # 関数に与えられた引数が必要条件を満たしていない
    BadArgument = 0x00000003

    # 初期化が必要なモジュールを初期化せずに使用しようとした
    NotInitialized = 0x00000004

    # マップに登録されているオブジェクトを得ようとしたが登録されていなかった
    EntryNotFound = 0x00000006

    # ファイルまたはディレクトリがない
    FileNotFound = 0x00000007

    # オープンされていないファイルにオープンが必要な操作を行おうとした
    FileNotOpen = 0x00000008

    # 作成しようとしているファイルは存在する
    FileAlreadyExisted = 0x00000009

    # 読み取り専用でオープンしているファイルに書き込もうとするなど、許されていない種類のアクセスを行おうとした
    IllegalFileAccess = 0x0000000b

    # ある操作の権限がないにもかかわらず、その操作を行おうとした
    PermissionDenied = 0x0000000d

    # オープンしようとしているファイルはオープンされている
    FileAlreadyOpened = 0x0000000e

    # 書き込みを行おうとしたファイルのあるディスクに空き領域がない
    DiskFull = 0x0000000f

    # アサーションでチェックしている条件が満たされなかった
    AssertionFailed = 0x000000fe

    # MODライブラリが例外を投げた
    ModLibraryError = 0x0000ffff

    # ファイルを上限までオープンしている
    TooManyOpenFiles = 0x00000010

    # 暗号ライブラリがエラーを返した
    CryptLibraryError = 0x00000011

    # パスワードファイルを解析中にエラーが発生した
    BadPasswordFile = 0x00000012

    # 内部パラメータ解析中にエラーが発生した
    WrongParameter = 0x00000013

    # データベースが変更された
    DatabaseChanged = 0x00000014

    # 続行不可能なエラーが発生し、レプリケーション処理を続けることができない
    ReplicationAborted = 0x00000015

    # 致命的エラー
    Fatal = 0x000000ff

    # 古いバージョンのクライアントが新しいバージョンで追加された例外をキャッチした
    UnknownException = 0x00000fff

    # 指定したIDを持つクラスがない
    ClassNotFound = 0x00010001

    # 与えられた名前のライブラリーは存在しない
    LibraryNotFound = 0x00010003

    # ライブラリーに存在しない関数を実行しようとした
    FunctionNotFound = 0x00010004

    # ユーザーからのキャンセル要求により実行が停止された
    Cancel = 0x00020001

    # サーバーへの接続に失敗した
    CannotConnect = 0x00020002

    # リクエスト番号が不正な値であった
    UnknownRequest = 0x00020003

    # セッションが返答できない状況で新たなリクエストを要求した
    SessionBusy = 0x00020004

    # シャットダウン中にリクエストを要求した
    GoingShutdown = 0x00020005

    # 処理中に接続が切れた
    ConnectionRanOut = 0x00020006

    # サーバが利用できない状態である
    ServerNotAvailable = 0x00020007

    # セッションが利用できない状態である
    SessionNotAvailable = 0x00020008

    # サーバが二重に立ち上げられた
    DuplicateServer = 0x0002000a

    # クライアントがサーバとの接続をクローズした
    ConnectionClosed = 0x0002000b

    # データベースが利用できない状態である
    DatabaseNotAvailable = 0x0002000c

    # スーパーユーザーがセッションをキャンセルした。
    CanceledBySuperUser = 0x0002000d

    # 再構成処理を正しく終了することができなかった
    ReorganizeFailed = 0x00040008

    # メタデータベースの内容を正しく読み込むことができなかった
    MetaDatabaseCorrupted = 0x00040009

    # データベースの内容を正しく読み込むことができなかった
    DatabaseCorrupted = 0x0004000a

    # 読み取り専用のデータベースを書き換えようとした
    ReadOnlyDatabase = 0x0004000b

    # 操作不能のデータベースを操作しようとした
    OfflineDatabase = 0x0004000c

    # 一時データベースに対して禁止されている操作を行おうとした
    TemporaryDatabase = 0x0004000d

    # システム表に許されない操作をしようとした
    SystemTable = 0x0004000e

    # SQL文が長すぎてTreeNode数の上限に達した
    TooLongStatement = 0x00050001

    # SQL文の可変パラメーターによりprepare時に最適化が完了できなかった
    PrepareFailed = 0x00050002

    # 物理的なファイル操作に失敗した
    FileManipulateError = 0x00070002

    # 転置リストの領域がオーバーフローしたのでこれ以上登録できない
    ListFormatOverflow = 0x00070003

    # 条件パターンが長いので検索することができない
    TooLongConditionalPattern = 0x00070004

    # ファイルに不整合があり、整合性検査を続けることができない
    VerifyAborted = 0x00070005

    # 展開パターンが多いので検索することができない
    TooManyExpandedPattern = 0x00070006

    # 時間切れが起きた
    LockTimeout = 0x0008001

    # デッドロックが起きた
    Deadlock = 0x0008002

    # 親ロック項目に十分なロックが掛けられていない
    LackOfParent = 0x0008003

    # 子ロック項目に十分なロックでなくなる
    LackForChild = 0x0008004

    # タイムスタンプファイルの内容を正しく読み込むことができなかった
    TimeStampFileCorrupted = 0x00090005

    # ログファイルの内容を正しく読み込むことができなかった
    LogFileCorrupted = 0x000A0001

    # ログファイルの内容を正しく読み込むことができなかった
    LogItemCorrupted = 0x000A0002

    # 指定されたログ情報が存在しなかった
    LogItemNotFound = 0x000A0003

    # リカバリー中に回復不能なエラーが発生した。
    RecoveryFailed = 0x000B0001

    # WITH RECOVERを指定していないにもかかわらず、アンマウントやバックアップされていないデータベースをマウントしようとした。アンマウントされていないデータベースをREAD ONLYでマウントしようとした。
    DatabaseNotMountable = 0x000C0001

    # バックアップを行ったトランザクションの開始時のスナップショットが破棄されているにもかかわらず、そのトランザクションの開始時点の状態にバックアップされたデータベースをマウントしようとした。
    SnapshotDiscarded = 0x000C0002

    # バッファのフラッシュを差し止める操作を実行中に、バッファをフラッシュしようとした。
    FlushPrevented = 0x000D0001

    # ファイルから読み出したページのチェックサムを計算したところ、書き込み時に計算したものと異なっている。
    BadDataPage = 0x000D0002

    # ファイルから読み出したページのページIDを参照したところ、本来格納されるべきページIDとは違うページIDが格納されていた。
    PreservedDifferentPage = 0x000D0003

    # チェックポイントが実行中なのに、チェックポイントと排他するような処理を開始しようとした。チェックポイントの終了を待たずにエラーにする場合に利用する。
    RunningCheckpointProcessing = 0x000D0004

    # バックアップを開始していないデータベースのバックアップを終了しようとした。
    NotStartBackup = 0x000E0001

    # 他のトランザクションがバックアップ中のデータベースのバックアップを開始しようとした。
    AlreadyStartBackup = 0x000E0002

    # システムコールでエラーが発生した。
    SystemCall = 0x000F0001
