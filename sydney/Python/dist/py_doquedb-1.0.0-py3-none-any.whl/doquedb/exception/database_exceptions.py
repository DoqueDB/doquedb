"""database_execption.py -- 自動生成された例外クラスのモジュール
"""
from typing import Optional

from ..common.serialdata import ExceptionData
from .exceptions import DatabaseError
from .errorcode import ErrorCode
from .error_message import ErrorMessage


class DynamicParameterNotMatch(DatabaseError):
    """?を用いたSQL文に対して必要な数のパラメーターが指定されていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "07001",
                ErrorCode.DynamicParameterNotMatch.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "07001",
                ErrorCode.DynamicParameterNotMatch.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DynamicParameterNotMatch.value,
            arguments)


class ConnectionNotExist(DatabaseError):
    """存在しないセッションIDが渡された"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "08003",
                ErrorCode.ConnectionNotExist.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "08003",
                ErrorCode.ConnectionNotExist.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ConnectionNotExist.value,
            arguments)


class ClientNotExist(DatabaseError):
    """存在しないクライアントIDが渡された"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "08003",
                ErrorCode.ClientNotExist.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "08003",
                ErrorCode.ClientNotExist.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ClientNotExist.value,
            arguments)


class SessionNotExist(DatabaseError):
    """存在しないセッションIDが渡された"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "08003",
                ErrorCode.SessionNotExist.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "08003",
                ErrorCode.SessionNotExist.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SessionNotExist.value,
            arguments)


class AuthorizationFailed(DatabaseError):
    """正しくないパスワードが指定された"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "08501",
                ErrorCode.AuthorizationFailed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "08501",
                ErrorCode.AuthorizationFailed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.AuthorizationFailed.value,
            arguments)


class NotSupported(DatabaseError):
    """実装されていない機能を使用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "0A000",
                ErrorCode.NotSupported.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "0A000",
                ErrorCode.NotSupported.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NotSupported.value,
            arguments)


class FullTextIndexNeeded(DatabaseError):
    """全文索引が定義されていないのに全文索引が必要な機能を使用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "0A501",
                ErrorCode.FullTextIndexNeeded.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "0A501",
                ErrorCode.FullTextIndexNeeded.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FullTextIndexNeeded.value,
            arguments)


class SpatialIndexNeeded(DatabaseError):
    """空間索引が定義されていないのに空間索引が必要な機能を使用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "0A502",
                ErrorCode.SpatialIndexNeeded.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "0A502",
                ErrorCode.SpatialIndexNeeded.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SpatialIndexNeeded.value,
            arguments)


class RoleNotFound(DatabaseError):
    """指定されたロールが登録されていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "0P501",
                ErrorCode.RoleNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "0P501",
                ErrorCode.RoleNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.RoleNotFound.value,
            arguments)


class CardinalityViolation(DatabaseError):
    """row subqueryにあたる場所で結果が2行以上だった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "21000",
                ErrorCode.CardinalityViolation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "21000",
                ErrorCode.CardinalityViolation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CardinalityViolation.value,
            arguments)


class StringRightTruncation(DatabaseError):
    """制限長のある文字列型へのキャストで制限長を超える部分があった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22001",
                ErrorCode.StringRightTruncation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22001",
                ErrorCode.StringRightTruncation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.StringRightTruncation.value,
            arguments)


class NumericValueOutOfRange(DatabaseError):
    """四則演算などの結果数値型で表現できる範囲を超える操作があった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22003",
                ErrorCode.NumericValueOutOfRange.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22003",
                ErrorCode.NumericValueOutOfRange.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NumericValueOutOfRange.value,
            arguments)


class NullNotAllowed(DatabaseError):
    """ナル値が許されない操作をした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22004",
                ErrorCode.NullNotAllowed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22004",
                ErrorCode.NullNotAllowed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NullNotAllowed.value,
            arguments)


class InvalidDatetimeFormat(DatabaseError):
    """日時型へのキャストで日時型に変換できない文字列が渡された。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22007",
                ErrorCode.InvalidDatetimeFormat.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22007",
                ErrorCode.InvalidDatetimeFormat.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidDatetimeFormat.value,
            arguments)


class SequenceLimitExceeded(DatabaseError):
    """シーケンスの値が最大値になった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "2200H",
                ErrorCode.SequenceLimitExceeded.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "2200H",
                ErrorCode.SequenceLimitExceeded.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SequenceLimitExceeded.value,
            arguments)


class SubStringError(DatabaseError):
    """SUBSTRINGでstart positionが長さを超えていた。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22011",
                ErrorCode.SubStringError.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22011",
                ErrorCode.SubStringError.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SubStringError.value,
            arguments)


class DivisionByZero(DatabaseError):
    """割り算のdivisorが0だった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22012",
                ErrorCode.DivisionByZero.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22012",
                ErrorCode.DivisionByZero.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DivisionByZero.value,
            arguments)


class InvalidCharacter(DatabaseError):
    """文字列型をキャストするときにターゲットの型に対して不正な文字が含まれていた。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22018",
                ErrorCode.InvalidCharacter.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22018",
                ErrorCode.InvalidCharacter.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidCharacter.value,
            arguments)


class InvalidEscape(DatabaseError):
    """LikeやSimilarに指定したエスケープ文字の長さが1でなかった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22019",
                ErrorCode.InvalidEscape.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22019",
                ErrorCode.InvalidEscape.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidEscape.value,
            arguments)


class InvalidRegularExpression(DatabaseError):
    """Similarに指定した正規表現が正しくない。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "2201B",
                ErrorCode.InvalidRegularExpression.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "2201B",
                ErrorCode.InvalidRegularExpression.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidRegularExpression.value,
            arguments)


class CharacterNotInRepertoire(DatabaseError):
    """char型の列にASCII以外の文字を渡した。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22021",
                ErrorCode.CharacterNotInRepertoire.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22021",
                ErrorCode.CharacterNotInRepertoire.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CharacterNotInRepertoire.value,
            arguments)


class InvalidEscapeSequence(DatabaseError):
    """以下の条件を満たさなかった: likeのパターンが1文字か2文字の部分に分解できて、1文字の部分はエスケープ文字以外からなり、2文字の部分はエスケープ文字とエスケープ文字かアンダースコアかパーセント記号の連結である。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22025",
                ErrorCode.InvalidEscapeSequence.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22025",
                ErrorCode.InvalidEscapeSequence.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidEscapeSequence.value,
            arguments)


class NonCharacterInString(DatabaseError):
    """文字列中にUCSではないデータが含まれている。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22029",
                ErrorCode.NonCharacterInString.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22029",
                ErrorCode.NonCharacterInString.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NonCharacterInString.value,
            arguments)


class BadArrayElement(DatabaseError):
    """ARRAYの要素指定が範囲外だった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "2202E",
                ErrorCode.BadArrayElement.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "2202E",
                ErrorCode.BadArrayElement.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.BadArrayElement.value,
            arguments)


class ArrayRightTruncation(DatabaseError):
    """ARRAYの代入で代入もとの要素数が代入先の最大長を超えていた。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "2202F",
                ErrorCode.ArrayRightTruncation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "2202F",
                ErrorCode.ArrayRightTruncation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ArrayRightTruncation.value,
            arguments)


class ClassCast(DatabaseError):
    """オブジェクトの内容を別のクラスにキャストしようとして失敗した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22501",
                ErrorCode.ClassCast.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22501",
                ErrorCode.ClassCast.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ClassCast.value,
            arguments)


class InvalidSectionData(DatabaseError):
    """全文索引に使うセクションデータと言語データの次数があっていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22502",
                ErrorCode.InvalidSectionData.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "22502",
                ErrorCode.InvalidSectionData.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidSectionData.value,
            arguments)


class InvalidDataFile(DatabaseError):
    """INSERT INPUT FROM構文などで指定したデータファイルが規定のフォーマットに合わない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "22510",
                ErrorCode.InvalidDataFile.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "22510",
                ErrorCode.InvalidDataFile.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidDataFile.value,
            arguments)


class IntegrityViolation(DatabaseError):
    """それを実行するとインテグリティを破ってしまうようなデータ操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "23000",
                ErrorCode.IntegrityViolation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "23000",
                ErrorCode.IntegrityViolation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.IntegrityViolation.value,
            arguments)


class NullabilityViolation(DatabaseError):
    """挿入または更新でNOT NULLの制約がついている列にNULLの値を設定しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "23501",
                ErrorCode.NullabilityViolation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "23501",
                ErrorCode.NullabilityViolation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NullabilityViolation.value,
            arguments)


class UniquenessViolation(DatabaseError):
    """UNIQUE制約に違反するデータ操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "23502",
                ErrorCode.UniquenessViolation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "23502",
                ErrorCode.UniquenessViolation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.UniquenessViolation.value,
            arguments)


class ForeignKeyViolation(DatabaseError):
    """外部キーで参照しているレコードに存在しない値を設定しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "23003",
                ErrorCode.ForeignKeyViolation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "23003",
                ErrorCode.ForeignKeyViolation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ForeignKeyViolation.value,
            arguments)


class ReferedKeyViolation(DatabaseError):
    """外部キーで参照されている列を削除または更新しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "23004",
                ErrorCode.ReferedKeyViolation.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "23004",
                ErrorCode.ReferedKeyViolation.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ReferedKeyViolation.value,
            arguments)


class AlreadyBeginTransaction(DatabaseError):
    """トランザクション中にトランザクションを開始しようとした。または、トランザクションブランチを開始もしくは待機しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25001",
                ErrorCode.AlreadyBeginTransaction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25001",
                ErrorCode.AlreadyBeginTransaction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.AlreadyBeginTransaction.value,
            arguments)


class XA_InsideActiveBranch(DatabaseError):
    """データ操作中のトランザクションブランチにおいて不可なトランザクション操作・トランザクションブランチ操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25002",
                ErrorCode.XA_InsideActiveBranch.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25002",
                ErrorCode.XA_InsideActiveBranch.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_InsideActiveBranch.value,
            arguments)


class ReadOnlyTransaction(DatabaseError):
    """読み取り専用トランザクションで許されない操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25006",
                ErrorCode.ReadOnlyTransaction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25006",
                ErrorCode.ReadOnlyTransaction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ReadOnlyTransaction.value,
            arguments)


class InvalidExplicitTransaction(DatabaseError):
    """明示的に開始されたトランザクション中にスキーマ操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25501",
                ErrorCode.InvalidExplicitTransaction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25501",
                ErrorCode.InvalidExplicitTransaction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidExplicitTransaction.value,
            arguments)


class NotBeginTransaction(DatabaseError):
    """トランザクション中に行うべき処理をトランザクションを開始せずに行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25502",
                ErrorCode.NotBeginTransaction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25502",
                ErrorCode.NotBeginTransaction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NotBeginTransaction.value,
            arguments)


class BadTransaction(DatabaseError):
    """トランザクションの読み書き属性かアイソレーションレベルが行おうとした操作で許されていないものだった。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25503",
                ErrorCode.BadTransaction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25503",
                ErrorCode.BadTransaction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.BadTransaction.value,
            arguments)


class XA_DuplicateIdentifier(DatabaseError):
    """『データ操作中』・『中断中』・『待機中』のトランザクションブランチのトランザクションブランチ識別子を指定して新たにトランザクションブランチを開始した。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25504",
                ErrorCode.XA_DuplicateIdentifier.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25504",
                ErrorCode.XA_DuplicateIdentifier.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_DuplicateIdentifier.value,
            arguments)


class XA_ProtocolError(DatabaseError):
    """ある状態のトランザクションブランチに対して許されない操作を行おうとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25505",
                ErrorCode.XA_ProtocolError.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25505",
                ErrorCode.XA_ProtocolError.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_ProtocolError.value,
            arguments)


class XA_UnknownIdentifier(DatabaseError):
    """存在しないトランザクションブランチ識別子が指定された。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25506",
                ErrorCode.XA_UnknownIdentifier.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25506",
                ErrorCode.XA_UnknownIdentifier.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_UnknownIdentifier.value,
            arguments)


class XA_HeurCommit(DatabaseError):
    """トランザクションブランチはコミットしてヒューリスティックに解決済である。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25507",
                ErrorCode.XA_HeurCommit.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25507",
                ErrorCode.XA_HeurCommit.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_HeurCommit.value,
            arguments)


class XA_HeurRollback(DatabaseError):
    """トランザクションブランチはロールバックしてヒューリスティックに解決済である。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25508",
                ErrorCode.XA_HeurRollback.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25508",
                ErrorCode.XA_HeurRollback.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_HeurRollback.value,
            arguments)


class XA_HeurMix(DatabaseError):
    """トランザクションブランチは部分的にコミットされ、そして部分的にロールバックしてヒューリスティックに解決済である。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "25509",
                ErrorCode.XA_HeurMix.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "25509",
                ErrorCode.XA_HeurMix.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_HeurMix.value,
            arguments)


class XA_InvalidIdentifier(DatabaseError):
    """不正なトランザクションブランチ識別子が指定された。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "2550A",
                ErrorCode.XA_InvalidIdentifier.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "2550A",
                ErrorCode.XA_InvalidIdentifier.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.XA_InvalidIdentifier.value,
            arguments)


class OtherDatabaseAlreadyModified(DatabaseError):
    """1つのトランザクションまたはトランザクションブランチで2つのデータベースを更新しようとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "2550B",
                ErrorCode.OtherDatabaseAlreadyModified.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "2550B",
                ErrorCode.OtherDatabaseAlreadyModified.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.OtherDatabaseAlreadyModified.value,
            arguments)


class UserNotFound(DatabaseError):
    """指定されたユーザーが登録されていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28501",
                ErrorCode.UserNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "28501",
                ErrorCode.UserNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.UserNotFound.value,
            arguments)


class UserRequired(DatabaseError):
    """ユーザー名が指定されていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28502",
                ErrorCode.UserRequired.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "28502",
                ErrorCode.UserRequired.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.UserRequired.value,
            arguments)


class DuplicateUser(DatabaseError):
    """すでに登録済みのユーザー名でユーザーを作成しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28503",
                ErrorCode.DuplicateUser.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "28503",
                ErrorCode.DuplicateUser.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateUser.value,
            arguments)


class TooLongUserName(DatabaseError):
    """ユーザー名の長さが制限長を超えている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28504",
                ErrorCode.TooLongUserName.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "28504",
                ErrorCode.TooLongUserName.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TooLongUserName.value,
            arguments)


class InvalidUserName(DatabaseError):
    """ユーザー名にサポート外の文字が使用されている。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28505",
                ErrorCode.InvalidUserName.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "28505",
                ErrorCode.InvalidUserName.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidUserName.value,
            arguments)


class DuplicateUserID(DatabaseError):
    """すでに登録済みのユーザーIDを指定してユーザーを作成しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28506",
                ErrorCode.DuplicateUserID.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "28506",
                ErrorCode.DuplicateUserID.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateUserID.value,
            arguments)


class UserIDOutOfRange(DatabaseError):
    """ユーザーIDに使用できない数値が指定されている。または自動割当のユーザーIDが範囲を超えた。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "28507",
                ErrorCode.UserIDOutOfRange.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "28507",
                ErrorCode.UserIDOutOfRange.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.UserIDOutOfRange.value,
            arguments)


class InvalidStatementIdentifier(DatabaseError):
    """指定された識別子に対応するSQLステートメントがない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "30000",
                ErrorCode.InvalidStatementIdentifier.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "30000",
                ErrorCode.InvalidStatementIdentifier.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidStatementIdentifier.value,
            arguments)


class AreaNotFound(DatabaseError):
    """与えられた名前のエリアは存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F501",
                ErrorCode.AreaNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F501",
                ErrorCode.AreaNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.AreaNotFound.value,
            arguments)


class DatabaseNotFound(DatabaseError):
    """与えられた名前のデータベースは存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F502",
                ErrorCode.DatabaseNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "3F502",
                ErrorCode.DatabaseNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DatabaseNotFound.value,
            arguments)


class TableNotFound(DatabaseError):
    """与えられた名前の表は存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F503",
                ErrorCode.TableNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F503",
                ErrorCode.TableNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TableNotFound.value,
            arguments)


class ColumnNotFound(DatabaseError):
    """与えられた名前の列は存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F504",
                ErrorCode.ColumnNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "3F504",
                ErrorCode.ColumnNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ColumnNotFound.value,
            arguments)


class ConstraintNotFound(DatabaseError):
    """与えられた名前の制約は存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F505",
                ErrorCode.ConstraintNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F505",
                ErrorCode.ConstraintNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ConstraintNotFound.value,
            arguments)


class IndexNotFound(DatabaseError):
    """与えられた名前の索引は存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F506",
                ErrorCode.IndexNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F506",
                ErrorCode.IndexNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.IndexNotFound.value,
            arguments)


class KeyNotFound(DatabaseError):
    """与えられた名前のキーは存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F507",
                ErrorCode.KeyNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F507",
                ErrorCode.KeyNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.KeyNotFound.value,
            arguments)


class SchemaObjectNotFound(DatabaseError):
    """IDなどによるスキーマ情報の取得に失敗した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F508",
                ErrorCode.SchemaObjectNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "3F508",
                ErrorCode.SchemaObjectNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SchemaObjectNotFound.value,
            arguments)


class StoredFunctionNotFound(DatabaseError):
    """与えられた名前の関数は存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F509",
                ErrorCode.StoredFunctionNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F509",
                ErrorCode.StoredFunctionNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.StoredFunctionNotFound.value,
            arguments)


class CascadeNotFound(DatabaseError):
    """与えられた名前の子サーバーは存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F50A",
                ErrorCode.CascadeNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F50A",
                ErrorCode.CascadeNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CascadeNotFound.value,
            arguments)


class PartitionNotFound(DatabaseError):
    """与えられた名前の表にルールは存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F50B",
                ErrorCode.PartitionNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F50B",
                ErrorCode.PartitionNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.PartitionNotFound.value,
            arguments)


class AreaAlreadyDefined(DatabaseError):
    """与えられた名前のエリアがある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F511",
                ErrorCode.AreaAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F511",
                ErrorCode.AreaAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.AreaAlreadyDefined.value,
            arguments)


class DatabaseAlreadyDefined(DatabaseError):
    """与えられた名前のデータベースがある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F512",
                ErrorCode.DatabaseAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "3F512",
                ErrorCode.DatabaseAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DatabaseAlreadyDefined.value,
            arguments)


class TableAlreadyDefined(DatabaseError):
    """与えられた名前の表がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F513",
                ErrorCode.TableAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F513",
                ErrorCode.TableAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TableAlreadyDefined.value,
            arguments)


class ColumnAlreadyDefined(DatabaseError):
    """与えられた名前の列がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F514",
                ErrorCode.ColumnAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F514",
                ErrorCode.ColumnAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ColumnAlreadyDefined.value,
            arguments)


class ConstraintAlreadyDefined(DatabaseError):
    """与えられた名前の制約がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F515",
                ErrorCode.ConstraintAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F515",
                ErrorCode.ConstraintAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ConstraintAlreadyDefined.value,
            arguments)


class IndexAlreadyDefined(DatabaseError):
    """与えられた名前の索引がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F516",
                ErrorCode.IndexAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F516",
                ErrorCode.IndexAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.IndexAlreadyDefined.value,
            arguments)


class KeyAlreadyDefined(DatabaseError):
    """与えられた名前のキーがある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F517",
                ErrorCode.KeyAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F517",
                ErrorCode.KeyAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.KeyAlreadyDefined.value,
            arguments)


class CascadeAlreadyDefined(DatabaseError):
    """与えられた名前の子サーバーがある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F518",
                ErrorCode.CascadeAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F518",
                ErrorCode.CascadeAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CascadeAlreadyDefined.value,
            arguments)


class StoredFunctionAlreadyDefined(DatabaseError):
    """与えられた名前の関数がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F519",
                ErrorCode.StoredFunctionAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F519",
                ErrorCode.StoredFunctionAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.StoredFunctionAlreadyDefined.value,
            arguments)


class PartitionAlreadyDefined(DatabaseError):
    """与えられた名前の表にルール定義がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F51a",
                ErrorCode.PartitionAlreadyDefined.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F51a",
                ErrorCode.PartitionAlreadyDefined.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.PartitionAlreadyDefined.value,
            arguments)


class InvalidCascade(DatabaseError):
    """子サーバーの指定が正しくない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F51b",
                ErrorCode.InvalidCascade.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "3F51b",
                ErrorCode.InvalidCascade.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidCascade.value,
            arguments)


class InvalidPartition(DatabaseError):
    """ルールの指定が正しくない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F51c",
                ErrorCode.InvalidPartition.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "3F51c",
                ErrorCode.InvalidPartition.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidPartition.value,
            arguments)


class TableNotEmpty(DatabaseError):
    """表が空でないとできない操作をした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F51d",
                ErrorCode.TableNotEmpty.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "3F51d",
                ErrorCode.TableNotEmpty.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TableNotEmpty.value,
            arguments)


class StoredFunctionUsed(DatabaseError):
    """使用中の関数をDROPしようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F51e",
                ErrorCode.StoredFunctionUsed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "3F51e",
                ErrorCode.StoredFunctionUsed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.StoredFunctionUsed.value,
            arguments)


class ReadOnlyPartition(DatabaseError):
    """参照専用ルールの定義されている表に更新操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "3F51f",
                ErrorCode.ReadOnlyPartition.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "3F51f",
                ErrorCode.ReadOnlyPartition.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ReadOnlyPartition.value,
            arguments)


class SQLSyntaxError(DatabaseError):
    """構文が正しくないSQL文が与えられた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42000",
                ErrorCode.SQLSyntaxError.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42000",
                ErrorCode.SQLSyntaxError.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SQLSyntaxError.value,
            arguments)


class ColumnLengthOutOfRange(DatabaseError):
    """列に渡された長さが制限値を超えていた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42501",
                ErrorCode.ColumnLengthOutOfRange.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1], args[2]),
                "42501",
                ErrorCode.ColumnLengthOutOfRange.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ColumnLengthOutOfRange.value,
            arguments)


class TooLongObjectName(DatabaseError):
    """スキーマオブジェクト名の長さが制限値を超えていた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42502",
                ErrorCode.TooLongObjectName.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "42502",
                ErrorCode.TooLongObjectName.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TooLongObjectName.value,
            arguments)


class InvalidReference(DatabaseError):
    """外部キーで参照している列がUniqueではないなど正しく設定されていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42503",
                ErrorCode.InvalidReference.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42503",
                ErrorCode.InvalidReference.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidReference.value,
            arguments)


class InvalidPath(DatabaseError):
    """create databaseで指定されたパスがすでにあったり、mountで指定されたパスが存在しないなど"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42504",
                ErrorCode.InvalidPath.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42504",
                ErrorCode.InvalidPath.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidPath.value,
            arguments)


class TemporaryTable(DatabaseError):
    """一時表に対して許されていない操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42505",
                ErrorCode.TemporaryTable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42505",
                ErrorCode.TemporaryTable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TemporaryTable.value,
            arguments)


class DefaultNeeded(DatabaseError):
    """add columnでNOT NULL制約のついている列にはDEFAULT指定が必要である"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42506",
                ErrorCode.DefaultNeeded.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42506",
                ErrorCode.DefaultNeeded.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DefaultNeeded.value,
            arguments)


class InvalidDefault(DatabaseError):
    """列の型に代入可能でない型がDEFAULT指定で用いられている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42507",
                ErrorCode.InvalidDefault.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42507",
                ErrorCode.InvalidDefault.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidDefault.value,
            arguments)


class DuplicateIdentity(DatabaseError):
    """IDENTITY列は1つの表に1つしか定義できない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42508",
                ErrorCode.DuplicateIdentity.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "42508",
                ErrorCode.DuplicateIdentity.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateIdentity.value,
            arguments)


class InvalidIndexKey(DatabaseError):
    """索引のキーとしてサポートしていない型の列を指定した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42509",
                ErrorCode.InvalidIndexKey.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "42509",
                ErrorCode.InvalidIndexKey.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidIndexKey.value,
            arguments)


class ColumnPrecisionOutOfRange(DatabaseError):
    """列に渡された精度が制限値を超えていた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42510",
                ErrorCode.ColumnPrecisionOutOfRange.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1], args[2]),
                "42510",
                ErrorCode.ColumnPrecisionOutOfRange.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ColumnPrecisionOutOfRange.value,
            arguments)


class ColumnScaleOutOfRange(DatabaseError):
    """列に渡された桁が制限値を超えていた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42511",
                ErrorCode.ColumnScaleOutOfRange.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1], args[2]),
                "42511",
                ErrorCode.ColumnScaleOutOfRange.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ColumnScaleOutOfRange.value,
            arguments)


class InvalidIdentifier(DatabaseError):
    """識別子に使えない文字が含まれている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42512",
                ErrorCode.InvalidIdentifier.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42512",
                ErrorCode.InvalidIdentifier.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidIdentifier.value,
            arguments)


class InvalidAreaSpecification(DatabaseError):
    """レプリケーションが開始されているデータベースにエリア指定のあるスキーマ操作をした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42513",
                ErrorCode.InvalidAreaSpecification.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42513",
                ErrorCode.InvalidAreaSpecification.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidAreaSpecification.value,
            arguments)


class OtherObjectDepending(DatabaseError):
    """そのオブジェクトに依存している別のオブジェクトがあるのにdropなどの操作をしようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42601",
                ErrorCode.OtherObjectDepending.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42601",
                ErrorCode.OtherObjectDepending.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.OtherObjectDepending.value,
            arguments)


class PrivilegeNotAllowed(DatabaseError):
    """必要な権限が与えられていない操作をしようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42701",
                ErrorCode.PrivilegeNotAllowed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42701",
                ErrorCode.PrivilegeNotAllowed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.PrivilegeNotAllowed.value,
            arguments)


class InvalidDerivedColumn(DatabaseError):
    """導出列の数が表の列数と異なっていた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42801",
                ErrorCode.InvalidDerivedColumn.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "42801",
                ErrorCode.InvalidDerivedColumn.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidDerivedColumn.value,
            arguments)


class InvalidDerivedName(DatabaseError):
    """ROW型の値に別名をつけようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42802",
                ErrorCode.InvalidDerivedName.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42802",
                ErrorCode.InvalidDerivedName.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidDerivedName.value,
            arguments)


class DuplicateQualifiedName(DatabaseError):
    """同じスコープ中に表や列の別名を重複して使用している"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42803",
                ErrorCode.DuplicateQualifiedName.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42803",
                ErrorCode.DuplicateQualifiedName.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateQualifiedName.value,
            arguments)


class InvalidRowValue(DatabaseError):
    """ROW型値の比較などで異なる次数のものを指定している"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42804",
                ErrorCode.InvalidRowValue.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42804",
                ErrorCode.InvalidRowValue.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidRowValue.value,
            arguments)


class NotComparable(DatabaseError):
    """比較可能でない型同士を比較しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42805",
                ErrorCode.NotComparable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42805",
                ErrorCode.NotComparable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NotComparable.value,
            arguments)


class InvalidSubQuery(DatabaseError):
    """副問合せの使用位置が不正だった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42806",
                ErrorCode.InvalidSubQuery.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42806",
                ErrorCode.InvalidSubQuery.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidSubQuery.value,
            arguments)


class ExceedDegree(DatabaseError):
    """列の位置を指定するのに次数を超えた値を指定した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42807",
                ErrorCode.ExceedDegree.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "42807",
                ErrorCode.ExceedDegree.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ExceedDegree.value,
            arguments)


class InvalidExpandDegree(DatabaseError):
    """EXPAND句に1または2でない次数の副問い合わせを指定した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42808",
                ErrorCode.InvalidExpandDegree.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42808",
                ErrorCode.InvalidExpandDegree.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidExpandDegree.value,
            arguments)


class InvalidExpandOrder(DatabaseError):
    """EXPAND句に不正なORDER BYを指定した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42809",
                ErrorCode.InvalidExpandOrder.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42809",
                ErrorCode.InvalidExpandOrder.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidExpandOrder.value,
            arguments)


class InvalidExpandLimit(DatabaseError):
    """EXPAND句に不正なLIMITを指定した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42810",
                ErrorCode.InvalidExpandLimit.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42810",
                ErrorCode.InvalidExpandLimit.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidExpandLimit.value,
            arguments)


class InvalidFullTextUsage(DatabaseError):
    """SELECT句にWORDとSCOREなど同時に使用できないものを使用した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42811",
                ErrorCode.InvalidFullTextUsage.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42811",
                ErrorCode.InvalidFullTextUsage.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidFullTextUsage.value,
            arguments)


class InvalidSetFunction(DatabaseError):
    """集約関数をSELECT句、HAVING句、ORDER BY句以外に使用した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42812",
                ErrorCode.InvalidSetFunction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42812",
                ErrorCode.InvalidSetFunction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidSetFunction.value,
            arguments)


class NonGroupingColumn(DatabaseError):
    """GROUP BYで指定されていない列がグルーピングされたリレーションの中で単独で使用されている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42813",
                ErrorCode.NonGroupingColumn.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42813",
                ErrorCode.NonGroupingColumn.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NonGroupingColumn.value,
            arguments)


class InvalidElementReference(DatabaseError):
    """配列でないものに要素参照したか要素指定が数値でない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42814",
                ErrorCode.InvalidElementReference.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42814",
                ErrorCode.InvalidElementReference.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidElementReference.value,
            arguments)


class ArbitraryElementNotAllowed(DatabaseError):
    """配列の任意要素指定を使用できない箇所で使用している"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42815",
                ErrorCode.ArbitraryElementNotAllowed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42815",
                ErrorCode.ArbitraryElementNotAllowed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ArbitraryElementNotAllowed.value,
            arguments)


class CommonColumnNotFound(DatabaseError):
    """COLUMN指定のJOINで指定した名前の共通列がなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42816",
                ErrorCode.CommonColumnNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42816",
                ErrorCode.CommonColumnNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CommonColumnNotFound.value,
            arguments)


class DuplicateCommonColumn(DatabaseError):
    """COLUMN指定のJOINで指定した名前の列が複数あった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42817",
                ErrorCode.DuplicateCommonColumn.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42817",
                ErrorCode.DuplicateCommonColumn.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateCommonColumn.value,
            arguments)


class InvalidKwic(DatabaseError):
    """KwicがSELECT句以外に現れているか、引数が文字列でない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42818",
                ErrorCode.InvalidKwic.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42818",
                ErrorCode.InvalidKwic.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidKwic.value,
            arguments)


class KwicWithoutContains(DatabaseError):
    """KwicがCONTAINSなしに使用されている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42819",
                ErrorCode.KwicWithoutContains.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42819",
                ErrorCode.KwicWithoutContains.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.KwicWithoutContains.value,
            arguments)


class OuterReferenceNotAllowed(DatabaseError):
    """EXPAND句に外部参照がある"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42820",
                ErrorCode.OuterReferenceNotAllowed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42820",
                ErrorCode.OuterReferenceNotAllowed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.OuterReferenceNotAllowed.value,
            arguments)


class InvalidCardinality(DatabaseError):
    """配列でないものにCARDINALITYを適用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42821",
                ErrorCode.InvalidCardinality.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42821",
                ErrorCode.InvalidCardinality.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidCardinality.value,
            arguments)


class InvalidLike(DatabaseError):
    """文字列でないものにLIKEを適用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42822",
                ErrorCode.InvalidLike.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42822",
                ErrorCode.InvalidLike.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidLike.value,
            arguments)


class InvalidSimilar(DatabaseError):
    """文字列でないものにSIMILARを適用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42823",
                ErrorCode.InvalidSimilar.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42823",
                ErrorCode.InvalidSimilar.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidSimilar.value,
            arguments)


class NotCompatible(DatabaseError):
    """キャスト可能でない型同士に関数または演算子を適用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42824",
                ErrorCode.NotCompatible.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42824",
                ErrorCode.NotCompatible.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NotCompatible.value,
            arguments)


class InvalidFunction(DatabaseError):
    """関数の使用方法が正しくない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42825",
                ErrorCode.InvalidFunction.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42825",
                ErrorCode.InvalidFunction.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidFunction.value,
            arguments)


class VariableNotFound(DatabaseError):
    """定義されていない変数名を使用した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42826",
                ErrorCode.VariableNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42826",
                ErrorCode.VariableNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.VariableNotFound.value,
            arguments)


class DuplicateVariable(DatabaseError):
    """定義されている変数名と同じ名前を使用した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42827",
                ErrorCode.DuplicateVariable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42827",
                ErrorCode.DuplicateVariable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateVariable.value,
            arguments)


class InvalidRankFrom(DatabaseError):
    """RANK FROM句に異なる表を含む副問い合わせが使用されている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42828",
                ErrorCode.InvalidRankFrom.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42828",
                ErrorCode.InvalidRankFrom.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidRankFrom.value,
            arguments)


class InvalidSubstringOf(DatabaseError):
    """IS SUBSTRING OFの引数に配列でない値が指定されている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42829",
                ErrorCode.InvalidSubstringOf.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42829",
                ErrorCode.InvalidSubstringOf.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidSubstringOf.value,
            arguments)


class InvalidUpdateColumn(DatabaseError):
    """ROWIDなど更新操作で指定できない列が指定されている。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42850",
                ErrorCode.InvalidUpdateColumn.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42850",
                ErrorCode.InvalidUpdateColumn.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidUpdateColumn.value,
            arguments)


class DuplicateUpdateColumn(DatabaseError):
    """挿入や更新で同じ列が2回以上あらわれている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42851",
                ErrorCode.DuplicateUpdateColumn.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "42851",
                ErrorCode.DuplicateUpdateColumn.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateUpdateColumn.value,
            arguments)


class InvalidInsertSource(DatabaseError):
    """INSERT文の入力と列の数が一致しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42852",
                ErrorCode.InvalidInsertSource.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "42852",
                ErrorCode.InvalidInsertSource.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidInsertSource.value,
            arguments)


class InvalidBulkParameter(DatabaseError):
    """バルクオプションに誤りがある。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "42900",
                ErrorCode.InvalidBulkParameter.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "42900",
                ErrorCode.InvalidBulkParameter.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.InvalidBulkParameter.value,
            arguments)


class Unexpected(DatabaseError):
    """想定していないエラーが発生した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0501",
                ErrorCode.Unexpected.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0501",
                ErrorCode.Unexpected.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.Unexpected.value,
            arguments)


class MemoryExhaust(DatabaseError):
    """新たにメモリーを確保しようとしたが失敗した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0502",
                ErrorCode.MemoryExhaust.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0502",
                ErrorCode.MemoryExhaust.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.MemoryExhaust.value,
            arguments)


class BadArgument(DatabaseError):
    """関数に与えられた引数が必要条件を満たしていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0503",
                ErrorCode.BadArgument.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0503",
                ErrorCode.BadArgument.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.BadArgument.value,
            arguments)


class NotInitialized(DatabaseError):
    """初期化が必要なモジュールを初期化せずに使用しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0504",
                ErrorCode.NotInitialized.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0504",
                ErrorCode.NotInitialized.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NotInitialized.value,
            arguments)


class EntryNotFound(DatabaseError):
    """マップに登録されているオブジェクトを得ようとしたが登録されていなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0505",
                ErrorCode.EntryNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0505",
                ErrorCode.EntryNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.EntryNotFound.value,
            arguments)


class FileNotFound(DatabaseError):
    """ファイルまたはディレクトリがない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0506",
                ErrorCode.FileNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0506",
                ErrorCode.FileNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FileNotFound.value,
            arguments)


class FileNotOpen(DatabaseError):
    """オープンされていないファイルにオープンが必要な操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0507",
                ErrorCode.FileNotOpen.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0507",
                ErrorCode.FileNotOpen.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FileNotOpen.value,
            arguments)


class FileAlreadyExisted(DatabaseError):
    """作成しようとしているファイルは存在する"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0508",
                ErrorCode.FileAlreadyExisted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0508",
                ErrorCode.FileAlreadyExisted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FileAlreadyExisted.value,
            arguments)


class IllegalFileAccess(DatabaseError):
    """読み取り専用でオープンしているファイルに書き込もうとするなど、許されていない種類のアクセスを行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0510",
                ErrorCode.IllegalFileAccess.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0510",
                ErrorCode.IllegalFileAccess.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.IllegalFileAccess.value,
            arguments)


class PermissionDenied(DatabaseError):
    """ある操作の権限がないにもかかわらず、その操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0512",
                ErrorCode.PermissionDenied.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0512",
                ErrorCode.PermissionDenied.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.PermissionDenied.value,
            arguments)


class FileAlreadyOpened(DatabaseError):
    """オープンしようとしているファイルはオープンされている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0513",
                ErrorCode.FileAlreadyOpened.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0513",
                ErrorCode.FileAlreadyOpened.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FileAlreadyOpened.value,
            arguments)


class DiskFull(DatabaseError):
    """書き込みを行おうとしたファイルのあるディスクに空き領域がない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0514",
                ErrorCode.DiskFull.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0514",
                ErrorCode.DiskFull.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DiskFull.value,
            arguments)


class AssertionFailed(DatabaseError):
    """アサーションでチェックしている条件が満たされなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0515",
                ErrorCode.AssertionFailed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0515",
                ErrorCode.AssertionFailed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.AssertionFailed.value,
            arguments)


class ModLibraryError(DatabaseError):
    """MODライブラリが例外を投げた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0516",
                ErrorCode.ModLibraryError.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0516",
                ErrorCode.ModLibraryError.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ModLibraryError.value,
            arguments)


class TooManyOpenFiles(DatabaseError):
    """ファイルを上限までオープンしている"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0517",
                ErrorCode.TooManyOpenFiles.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0517",
                ErrorCode.TooManyOpenFiles.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TooManyOpenFiles.value,
            arguments)


class CryptLibraryError(DatabaseError):
    """暗号ライブラリがエラーを返した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0518",
                ErrorCode.CryptLibraryError.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0518",
                ErrorCode.CryptLibraryError.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CryptLibraryError.value,
            arguments)


class BadPasswordFile(DatabaseError):
    """パスワードファイルを解析中にエラーが発生した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0519",
                ErrorCode.BadPasswordFile.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0519",
                ErrorCode.BadPasswordFile.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.BadPasswordFile.value,
            arguments)


class WrongParameter(DatabaseError):
    """内部パラメータ解析中にエラーが発生した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0520",
                ErrorCode.WrongParameter.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0520",
                ErrorCode.WrongParameter.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.WrongParameter.value,
            arguments)


class DatabaseChanged(DatabaseError):
    """データベースが変更された"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0521",
                ErrorCode.DatabaseChanged.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0521",
                ErrorCode.DatabaseChanged.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DatabaseChanged.value,
            arguments)


class ReplicationAborted(DatabaseError):
    """続行不可能なエラーが発生し、レプリケーション処理を続けることができない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0522",
                ErrorCode.ReplicationAborted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0522",
                ErrorCode.ReplicationAborted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ReplicationAborted.value,
            arguments)


class Fatal(DatabaseError):
    """致命的エラー"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0ZZZ",
                ErrorCode.Fatal.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z0ZZZ",
                ErrorCode.Fatal.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.Fatal.value,
            arguments)


class UnknownException(DatabaseError):
    """古いバージョンのクライアントが新しいバージョンで追加された例外をキャッチした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z0ZZY",
                ErrorCode.UnknownException.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z0ZZY",
                ErrorCode.UnknownException.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.UnknownException.value,
            arguments)


class ClassNotFound(DatabaseError):
    """指定したIDを持つクラスがない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z1501",
                ErrorCode.ClassNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z1501",
                ErrorCode.ClassNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ClassNotFound.value,
            arguments)


class LibraryNotFound(DatabaseError):
    """与えられた名前のライブラリーは存在しない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z1502",
                ErrorCode.LibraryNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z1502",
                ErrorCode.LibraryNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LibraryNotFound.value,
            arguments)


class FunctionNotFound(DatabaseError):
    """ライブラリーに存在しない関数を実行しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z1503",
                ErrorCode.FunctionNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "Z1503",
                ErrorCode.FunctionNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FunctionNotFound.value,
            arguments)


class Cancel(DatabaseError):
    """ユーザーからのキャンセル要求により実行が停止された"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2501",
                ErrorCode.Cancel.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2501",
                ErrorCode.Cancel.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.Cancel.value,
            arguments)


class CannotConnect(DatabaseError):
    """サーバーへの接続に失敗した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2502",
                ErrorCode.CannotConnect.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "Z2502",
                ErrorCode.CannotConnect.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CannotConnect.value,
            arguments)


class UnknownRequest(DatabaseError):
    """リクエスト番号が不正な値であった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2503",
                ErrorCode.UnknownRequest.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z2503",
                ErrorCode.UnknownRequest.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.UnknownRequest.value,
            arguments)


class SessionBusy(DatabaseError):
    """セッションが返答できない状況で新たなリクエストを要求した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2504",
                ErrorCode.SessionBusy.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2504",
                ErrorCode.SessionBusy.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SessionBusy.value,
            arguments)


class GoingShutdown(DatabaseError):
    """シャットダウン中にリクエストを要求した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2505",
                ErrorCode.GoingShutdown.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2505",
                ErrorCode.GoingShutdown.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.GoingShutdown.value,
            arguments)


class ConnectionRanOut(DatabaseError):
    """処理中に接続が切れた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2506",
                ErrorCode.ConnectionRanOut.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2506",
                ErrorCode.ConnectionRanOut.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ConnectionRanOut.value,
            arguments)


class ServerNotAvailable(DatabaseError):
    """サーバが利用できない状態である"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2507",
                ErrorCode.ServerNotAvailable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2507",
                ErrorCode.ServerNotAvailable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ServerNotAvailable.value,
            arguments)


class SessionNotAvailable(DatabaseError):
    """セッションが利用できない状態である"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2508",
                ErrorCode.SessionNotAvailable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2508",
                ErrorCode.SessionNotAvailable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SessionNotAvailable.value,
            arguments)


class DuplicateServer(DatabaseError):
    """サーバが二重に立ち上げられた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2510",
                ErrorCode.DuplicateServer.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2510",
                ErrorCode.DuplicateServer.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DuplicateServer.value,
            arguments)


class ConnectionClosed(DatabaseError):
    """クライアントがサーバとの接続をクローズした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2511",
                ErrorCode.ConnectionClosed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2511",
                ErrorCode.ConnectionClosed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ConnectionClosed.value,
            arguments)


class DatabaseNotAvailable(DatabaseError):
    """データベースが利用できない状態である"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2512",
                ErrorCode.DatabaseNotAvailable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z2512",
                ErrorCode.DatabaseNotAvailable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DatabaseNotAvailable.value,
            arguments)


class CanceledBySuperUser(DatabaseError):
    """スーパーユーザーがセッションをキャンセルした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z2513",
                ErrorCode.CanceledBySuperUser.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z2513",
                ErrorCode.CanceledBySuperUser.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.CanceledBySuperUser.value,
            arguments)


class ReorganizeFailed(DatabaseError):
    """再構成処理を正しく終了することができなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4501",
                ErrorCode.ReorganizeFailed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z4501",
                ErrorCode.ReorganizeFailed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ReorganizeFailed.value,
            arguments)


class MetaDatabaseCorrupted(DatabaseError):
    """メタデータベースの内容を正しく読み込むことができなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4502",
                ErrorCode.MetaDatabaseCorrupted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z4502",
                ErrorCode.MetaDatabaseCorrupted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.MetaDatabaseCorrupted.value,
            arguments)


class DatabaseCorrupted(DatabaseError):
    """データベースの内容を正しく読み込むことができなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4503",
                ErrorCode.DatabaseCorrupted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z4503",
                ErrorCode.DatabaseCorrupted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DatabaseCorrupted.value,
            arguments)


class ReadOnlyDatabase(DatabaseError):
    """読み取り専用のデータベースを書き換えようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4504",
                ErrorCode.ReadOnlyDatabase.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z4504",
                ErrorCode.ReadOnlyDatabase.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ReadOnlyDatabase.value,
            arguments)


class OfflineDatabase(DatabaseError):
    """操作不能のデータベースを操作しようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4505",
                ErrorCode.OfflineDatabase.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z4505",
                ErrorCode.OfflineDatabase.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.OfflineDatabase.value,
            arguments)


class TemporaryDatabase(DatabaseError):
    """一時データベースに対して禁止されている操作を行おうとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4506",
                ErrorCode.TemporaryDatabase.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z4506",
                ErrorCode.TemporaryDatabase.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TemporaryDatabase.value,
            arguments)


class SystemTable(DatabaseError):
    """システム表に許されない操作をしようとした"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z4507",
                ErrorCode.SystemTable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z4507",
                ErrorCode.SystemTable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SystemTable.value,
            arguments)


class TooLongStatement(DatabaseError):
    """SQL文が長すぎてTreeNode数の上限に達した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z5501",
                ErrorCode.TooLongStatement.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z5501",
                ErrorCode.TooLongStatement.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TooLongStatement.value,
            arguments)


class PrepareFailed(DatabaseError):
    """SQL文の可変パラメーターによりprepare時に最適化が完了できなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z5502",
                ErrorCode.PrepareFailed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z5502",
                ErrorCode.PrepareFailed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.PrepareFailed.value,
            arguments)


class FileManipulateError(DatabaseError):
    """物理的なファイル操作に失敗した"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z7501",
                ErrorCode.FileManipulateError.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z7501",
                ErrorCode.FileManipulateError.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FileManipulateError.value,
            arguments)


class ListFormatOverflow(DatabaseError):
    """転置リストの領域がオーバーフローしたのでこれ以上登録できない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z7502",
                ErrorCode.ListFormatOverflow.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z7502",
                ErrorCode.ListFormatOverflow.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.ListFormatOverflow.value,
            arguments)


class TooLongConditionalPattern(DatabaseError):
    """条件パターンが長いので検索することができない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z7503",
                ErrorCode.TooLongConditionalPattern.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z7503",
                ErrorCode.TooLongConditionalPattern.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TooLongConditionalPattern.value,
            arguments)


class VerifyAborted(DatabaseError):
    """ファイルに不整合があり、整合性検査を続けることができない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z7504",
                ErrorCode.VerifyAborted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z7504",
                ErrorCode.VerifyAborted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.VerifyAborted.value,
            arguments)


class TooManyExpandedPattern(DatabaseError):
    """展開パターンが多いので検索することができない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z7505",
                ErrorCode.TooManyExpandedPattern.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z7505",
                ErrorCode.TooManyExpandedPattern.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TooManyExpandedPattern.value,
            arguments)


class LockTimeout(DatabaseError):
    """時間切れが起きた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z8501",
                ErrorCode.LockTimeout.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z8501",
                ErrorCode.LockTimeout.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LockTimeout.value,
            arguments)


class Deadlock(DatabaseError):
    """デッドロックが起きた"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z8502",
                ErrorCode.Deadlock.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z8502",
                ErrorCode.Deadlock.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.Deadlock.value,
            arguments)


class LackOfParent(DatabaseError):
    """親ロック項目に十分なロックが掛けられていない"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z8503",
                ErrorCode.LackOfParent.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z8503",
                ErrorCode.LackOfParent.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LackOfParent.value,
            arguments)


class LackForChild(DatabaseError):
    """子ロック項目に十分なロックでなくなる"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z8504",
                ErrorCode.LackForChild.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "Z8504",
                ErrorCode.LackForChild.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LackForChild.value,
            arguments)


class TimeStampFileCorrupted(DatabaseError):
    """タイムスタンプファイルの内容を正しく読み込むことができなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "Z9501",
                ErrorCode.TimeStampFileCorrupted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "Z9501",
                ErrorCode.TimeStampFileCorrupted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.TimeStampFileCorrupted.value,
            arguments)


class LogFileCorrupted(DatabaseError):
    """ログファイルの内容を正しく読み込むことができなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZA501",
                ErrorCode.LogFileCorrupted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZA501",
                ErrorCode.LogFileCorrupted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LogFileCorrupted.value,
            arguments)


class LogItemCorrupted(DatabaseError):
    """ログファイルの内容を正しく読み込むことができなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZA502",
                ErrorCode.LogItemCorrupted.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZA502",
                ErrorCode.LogItemCorrupted.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LogItemCorrupted.value,
            arguments)


class LogItemNotFound(DatabaseError):
    """指定されたログ情報が存在しなかった"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZA503",
                ErrorCode.LogItemNotFound.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZA503",
                ErrorCode.LogItemNotFound.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.LogItemNotFound.value,
            arguments)


class RecoveryFailed(DatabaseError):
    """リカバリー中に回復不能なエラーが発生した。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZB501",
                ErrorCode.RecoveryFailed.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZB501",
                ErrorCode.RecoveryFailed.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.RecoveryFailed.value,
            arguments)


class DatabaseNotMountable(DatabaseError):
    """WITH RECOVERを指定していないにもかかわらず、アンマウントやバックアップされていないデータベースをマウントしようとした。アンマウントされていないデータベースをREAD ONLYでマウントしようとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZC501",
                ErrorCode.DatabaseNotMountable.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "ZC501",
                ErrorCode.DatabaseNotMountable.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.DatabaseNotMountable.value,
            arguments)


class SnapshotDiscarded(DatabaseError):
    """バックアップを行ったトランザクションの開始時のスナップショットが破棄されているにもかかわらず、そのトランザクションの開始時点の状態にバックアップされたデータベースをマウントしようとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZC502",
                ErrorCode.SnapshotDiscarded.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZC502",
                ErrorCode.SnapshotDiscarded.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SnapshotDiscarded.value,
            arguments)


class FlushPrevented(DatabaseError):
    """バッファのフラッシュを差し止める操作を実行中に、バッファをフラッシュしようとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZD501",
                ErrorCode.FlushPrevented.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZD501",
                ErrorCode.FlushPrevented.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.FlushPrevented.value,
            arguments)


class BadDataPage(DatabaseError):
    """ファイルから読み出したページのチェックサムを計算したところ、書き込み時に計算したものと異なっている。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZD502",
                ErrorCode.BadDataPage.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "ZD502",
                ErrorCode.BadDataPage.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.BadDataPage.value,
            arguments)


class PreservedDifferentPage(DatabaseError):
    """ファイルから読み出したページのページIDを参照したところ、本来格納されるべきページIDとは違うページIDが格納されていた。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZD503",
                ErrorCode.PreservedDifferentPage.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1], args[2]),
                "ZD503",
                ErrorCode.PreservedDifferentPage.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.PreservedDifferentPage.value,
            arguments)


class RunningCheckpointProcessing(DatabaseError):
    """チェックポイントが実行中なのに、チェックポイントと排他するような処理を開始しようとした。チェックポイントの終了を待たずにエラーにする場合に利用する。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZD504",
                ErrorCode.RunningCheckpointProcessing.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(),
                "ZD504",
                ErrorCode.RunningCheckpointProcessing.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.RunningCheckpointProcessing.value,
            arguments)


class NotStartBackup(DatabaseError):
    """バックアップを開始していないデータベースのバックアップを終了しようとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZE501",
                ErrorCode.NotStartBackup.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "ZE501",
                ErrorCode.NotStartBackup.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.NotStartBackup.value,
            arguments)


class AlreadyStartBackup(DatabaseError):
    """他のトランザクションがバックアップ中のデータベースのバックアップを開始しようとした。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZE502",
                ErrorCode.AlreadyStartBackup.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0]),
                "ZE502",
                ErrorCode.AlreadyStartBackup.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.AlreadyStartBackup.value,
            arguments)


class SystemCall(DatabaseError):
    """システムコールでエラーが発生した。"""

    def __init__(self, e_: Optional[ExceptionData] = None, *args):
        # ExceptionDataが与えられた場合
        if e_:
            super().__init__(
                e_.error_message,
                "ZF501",
                ErrorCode.SystemCall.value)
        # ExceptionDataが与えられなかった場合
        else:
            super().__init__(
                self.make_error_message(args[0], args[1]),
                "ZF501",
                ErrorCode.SystemCall.value)

    def make_error_message(self, *args) -> str:
        """エラーメッセージを作成する

        Returns:
            str: 作成したエラーメッセージ
        """
        arguments = []

        for arg in args:
            arguments.append(arg)

        return ErrorMessage.make_error_message(
            ErrorCode.SystemCall.value,
            arguments)
